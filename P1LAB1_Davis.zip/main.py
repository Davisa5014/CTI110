# CTI 110
# P1LAB1
# Anthony Davis
# 16 Sep 2021

# This is 7.12 from Zybooks

userNum = int(input())
userNumSquared = userNum * userNum   # Math Bug Fixed
   
print(userNumSquared)       # Output formatting issue here; fix it when instructed